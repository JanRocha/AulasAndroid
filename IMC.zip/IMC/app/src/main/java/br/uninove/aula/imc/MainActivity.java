package br.uninove.aula.imc;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends Activity {
    private RadioButton rbMasc;
    private RadioButton rbFem;
    private EditText txtPeso, txtAltura;
    private double imc = 0.0;
    private double peso = 0.0;
    private double altura = 0.0;
    private int genero;
    private String mensagem = "";
    private TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPeso = (EditText) findViewById(R.id.txtPeso);
        txtAltura = (EditText) findViewById(R.id.txtAltura);
        rbMasc = (RadioButton) findViewById(R.id.rbMasculino);
        rbFem = (RadioButton) findViewById(R.id.rbFeminino);
        txtPeso = (EditText) findViewById(R.id.txtPeso);
        txt = (TextView) findViewById(R.id.textView2);
    }

    public void CalcularIMC(View view) {
        this.genero = 0;
        this.altura = Double.parseDouble(txtAltura.getText().toString());
        this.peso = Double.parseDouble(txtPeso.getText().toString());
        this.imc = this.peso / (this.altura * this.altura);
        if (rbMasc.isChecked()) {
            this.genero = 1;
        } else if (rbFem.isChecked()) {
            this.genero = 2;
        }

        switch (this.genero) {
            case 1:
                if (this.imc < 20) {
                    this.mensagem = "Abaixo do peso";
                } else if (this.imc < 25) {
                    this.mensagem = "Normal";
                } else if (this.imc < 30) {
                    this.mensagem = "obsidade leve";
                } else if (this.imc < 40) {
                    this.mensagem = "obsidade moderada";
                } else {
                    this.mensagem = "obsidade Mórbida";
                }
                break;
            case 2:
                if (this.imc < 19) {
                    this.mensagem = "Abaixo do peso";
                } else if (this.imc < 24) {
                    this.mensagem = "Normal";
                } else if (this.imc < 29) {
                    this.mensagem = "obsidade leve";
                } else if (this.imc < 39) {
                    this.mensagem = "obsidade moderada";
                } else {
                    this.mensagem = "obsidade Mórbida";
                }
                break;
        }

        txt.setText(this.mensagem);
    }
}
